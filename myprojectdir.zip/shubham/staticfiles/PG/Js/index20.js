// Password Protection eye icon

const passwordInput = document.querySelector("#wifiPassword")
const eye = document.querySelector("#eye")
eye.addEventListener("click", function(){
    this.classList.toggle("fa-eye")
    const type = passwordInput.getAttribute("type") === "password" ? "text" : "password"
    passwordInput.setAttribute("type", type)
  })



// Wifi info Modal 

function editModal(){

    var editButton = document.getElementById("editBtn")
    var editInfo = document.getElementById("editInfo")
    var overlay = document.getElementById("overlay")
    var closeButton = document.getElementById("closeBtn")
    editButton.addEventListener("click",function editModal(){
    
        editInfo.style.display = "block"
        overlay.style.display = "block"
        
    })
    closeButton.addEventListener("click",function close(){
        editInfo.style.display="none"
        overlay.style.display="none"
    })
}
editModal()


// Slider

var slider = document.querySelector(".slider1")
var progressBar = document.getElementById("progressBar")
function fanSlider(){

    document.getElementById('speed').innerHTML = slider.value;
    
    
    slider.oninput = function(){
        slider.value=this.value
        progressBar.style.width = this.value + '%';
        document.getElementById("speed").innerHTML = this.value;
    }
}
fanSlider();





// Date and Time

function dateAndTime(){

    var weekdayId = document.getElementById("weekday")
    var weekday2Id = document.getElementById("weekday2")
    var monthId = document.getElementById("month")
    var month2Id = document.getElementById("month2")
    var dateId = document.getElementById("date")
    var date2Id = document.getElementById("date2")
    var hourId = document.getElementById("hour")
    var minuteId = document.getElementById("minute")
        
    const date = new Date()
    
    var month = date.toLocaleString('default',{month:'short'})
    
    monthId.innerHTML = month
    month2Id.innerHTML = month
    
    var weekday = date.toLocaleString('default',{weekday:'long'})
    
    weekdayId.innerHTML = weekday
    weekday2Id.innerHTML = weekday
    if(date.getDate()<10){
        dateId.innerHTML = "0"+date.getDate()
        date2Id.innerHTML = "0"+date.getDate()
    }else{
        dateId.innerHTML = date.getDate()
        date2Id.innerHTML = date.getDate()
    }
    
    var to_string_hour = date.getHours().toString()
    var to_string_minute = date.getMinutes().toString()
    
    if(to_string_hour.length !== 2){
        let hour = "0" + date.getHours()
        hourId.innerHTML = hour
        console.log(hour)
    }else{
        if(Number(date.getHours())>12){
            let hour = Number(date.getHours()) - 12
            if(hour<10){
                let hour_to_string = "0" + hour 
                hourId.innerHTML = hour_to_string
            }else{
                let hour_number = hour
                hourId.innerHTML = hour_number
            }
        }else{
            hourId.innerHTML = date.getHours()
        }
        
    }
    if(to_string_minute.length !== 2){
        if(Number(date.getHours()>12)){
            let minute = "0" + date.getMinutes() + " PM"
            minuteId.innerHTML = minute
        }else{
            let minute = "0" + date.getMinutes() + " AM"
            minuteId.innerHTML = minute
        }
            
    }else{
        if(Number(date.getHours()>12)){
            let minute =date.getMinutes() + " PM"
            minuteId.innerHTML = minute
        }
        else{
            let minute =date.getMinutes() + " AM"
            minuteId.innerHTML = minute
        }
        
    }
}
dateAndTime();



// console.log("yes");

// Move Out
const moveOut = document.getElementById("moveOut")

// Bulb
const light1 = document.getElementById("light1")
const light2 = document.getElementById("light2")
const light3 = document.getElementById("light3")
const light4 = document.getElementById("light4")

// Socket

const socket1 = document.getElementById("socket1")
const socket2 = document.getElementById("socket2")
const socket3 = document.getElementById("socket3")
const socket4 = document.getElementById("socket4")

// Heavy Equipments
const cooler = document.getElementById("cooler")
const freeze = document.getElementById("freeze")
const ac = document.getElementById("ac")

// console.log("adding all ids")
// console.log(light1.value)
// console.log(typeof(light1.value))


// Testing in local Storage
// function checkInLocalSystem(){

//     if(localStorage.getItem("light1")=="true"){
//         light1.checked=true
//     }
//     // console.log(light1.value)
//     console.log(typeof(light1.value))

// }
// checkInLocalSystem();





// Frontend to Backend via Ajax
function frontToBack(){
    $("#light1").change(function(){
    
        var light1ToFrontend = 0
        if(light1.checked){
            light1ToFrontend = 1
        }
        light1.value = light1ToFrontend
        $.ajax({
            type:'POST',
            url:'applianceStatus/',
            data:({
                'statuslight1':light1ToFrontend,
                'statuslight2':light2.value,
                'statuslight3':light3.value,
                'statuslight4':light4.value,
                'statussocket1':socket1.value,        
                'statussocket2':socket2.value,
                'statussocket3':socket3.value,
                'statussocket4':socket4.value,
                'statuscooler':cooler.value,
                'statusfreeze':freeze.value,
                'statusac':ac.value,
                'statusslider':slider.value

            }) ,  
            success:function(response){
                console.log("success")
            },
            error: function(response){
                console.log("Failed")
            }
        })
    
    })
    
    $("#light2").change(function(){
    
        var light2ToFrontend = 0
        if(light2.checked){
            light2ToFrontend = 1
        }
        light2.value = light2ToFrontend
        $.ajax({
            type:'POST',
            url:'applianceStatus/',
            data:({
                'statuslight1':light1.value,
                'statuslight2':light2ToFrontend,
                'statuslight3':light3.value,
                'statuslight4':light4.value,
                'statussocket1':socket1.value,        
                'statussocket2':socket2.value,
                'statussocket3':socket3.value,
                'statussocket4':socket4.value,
                'statuscooler':cooler.value,
                'statusfreeze':freeze.value,
                'statusac':ac.value,
                'statusslider':slider.value

            }) ,  
            success:function(response){
                console.log("success")
            },
            error: function(response){
                console.log("Failed")
            }
        })
    
    })
    $("#light3").change(function(){
    
        var light3ToFrontend = 0
        if(light3.checked){
            light3ToFrontend = 1
        }
        light3.value=light3ToFrontend
        $.ajax({
            type:'POST',
            url:'applianceStatus/',
            data:({
                'statuslight1':light1.value,
                'statuslight2':light2.value,
                'statuslight3':light3ToFrontend,
                'statuslight4':light4.value,
                'statussocket1':socket1.value,        
                'statussocket2':socket2.value,
                'statussocket3':socket3.value,
                'statussocket4':socket4.value,
                'statuscooler':cooler.value,
                'statusfreeze':freeze.value,
                'statusac':ac.value,
                'statusslider':slider.value

            }) ,  
            success:function(response){
                console.log("success")
            },
            error: function(response){
                console.log("Failed")
            }
        })
    })
    $("#light4").change(function(){
    
        var light4ToFrontend = 0
        if(light4.checked){
            light4ToFrontend = 1
        }
        light4.value=light4ToFrontend
        $.ajax({
            type:'POST',
            url:'applianceStatus/',
            data:({
                'statuslight1':light1.value,
                'statuslight2':light2.value,
                'statuslight3':light3.value,
                'statuslight4':light4ToFrontend,
                'statussocket1':socket1.value,        
                'statussocket2':socket2.value,
                'statussocket3':socket3.value,
                'statussocket4':socket4.value,
                'statuscooler':cooler.value,
                'statusfreeze':freeze.value,
                'statusac':ac.value,
                'statusslider':slider.value

            }) ,  
            success:function(response){
                console.log("success")
            },
            error: function(response){
                console.log("Failed")
            }
        })
    
    })
    $("#socket1").change(function(){
    
        let socket1ToFrontend;
        if(socket1.checked){
            socket1ToFrontend = 1
        }else{
            socket1ToFrontend = 0
        }
        socket1.value = socket1ToFrontend

        $.ajax({
            type:'POST',
            url:'applianceStatus/',
            data:({
                'statuslight1':light1.value,
                'statuslight2':light2.value,
                'statuslight3':light3.value,
                'statuslight4':light4.value,
                'statussocket1':socket1ToFrontend,        
                'statussocket2':socket2.value,
                'statussocket3':socket3.value,
                'statussocket4':socket4.value,
                'statuscooler':cooler.value,
                'statusfreeze':freeze.value,
                'statusac':ac.value,
                'statusslider':slider.value

            }) ,  
            success:function(response){
                console.log("success")
            },
            error: function(response){
                console.log("Failed")
            }
        })
    
    })
    $("#socket2").change(function(){
    
        let socket2ToFrontend;
        if(socket2.checked){
            socket2ToFrontend = 1
        }else{
            socket2ToFrontend = 0
        }
        socket2.value=socket2ToFrontend
        $.ajax({
            type:'POST',
            url:'applianceStatus/',
            data:({
                'statuslight1':light1.value,
                'statuslight2':light2.value,
                'statuslight3':light3.value,
                'statuslight4':light4.value,
                'statussocket1':socket1.value,        
                'statussocket2':socket2ToFrontend,
                'statussocket3':socket3.value,
                'statussocket4':socket4.value,
                'statuscooler':cooler.value,
                'statusfreeze':freeze.value,
                'statusac':ac.value,
                'statusslider':slider.value

            }) ,  
            success:function(response){
                console.log("success")
            },
            error: function(response){
                console.log("Failed")
            }
        })
    
    })
    $("#socket3").change(function(){
    
        let socket3ToFrontend;
        if(socket3.checked){
            socket3ToFrontend = 1
        }else{
            socket3ToFrontend = 0
        }
        socket3.value=socket3ToFrontend
        $.ajax({
            type:'POST',
            url:'applianceStatus/',
            data:({
                'statuslight1':light1.value,
                'statuslight2':light2.value,
                'statuslight3':light3.value,
                'statuslight4':light4.value,
                'statussocket1':socket1.value,        
                'statussocket2':socket2.value,
                'statussocket3':socket3ToFrontend,
                'statussocket4':socket4.value,
                'statuscooler':cooler.value,
                'statusfreeze':freeze.value,
                'statusac':ac.value,
                'statusslider':slider.value

            }) ,  
            success:function(response){
                console.log("success")
            },
            error: function(response){
                console.log("Failed")
            }
        })
    
    })
    $("#socket4").change(function(){
    
        let socket4ToFrontend;
        if(socket4.checked){
            socket4ToFrontend = 1
        }else{
            socket4ToFrontend = 0
        }
        socket4.value=socket4ToFrontend
        $.ajax({
            type:'POST',
            url:'applianceStatus/',
            data:({
                'statuslight1':light1.value,
                'statuslight2':light2.value,
                'statuslight3':light3.value,
                'statuslight4':light4.value,
                'statussocket1':socket1.value,        
                'statussocket2':socket2.value,
                'statussocket3':socket3.value,
                'statussocket4':socket4ToFrontend,
                'statuscooler':cooler.value,
                'statusfreeze':freeze.value,
                'statusac':ac.value,
                'statusslider':slider.value

            }) ,  
            success:function(response){
                console.log("success")
            },
            error: function(response){
                console.log("Failed")
            }
        })
    
    })
    $("#cooler").change(function(){
    
        let coolerToFrontend;
        if(cooler.checked){
            coolerToFrontend = 1
        }else{
            coolerToFrontend = 0
        }
        cooler.value=coolerToFrontend
        $.ajax({
            type:'POST',
            url:'applianceStatus/',
            data:({
                'statuslight1':light1.value,
                'statuslight2':light2.value,
                'statuslight3':light3.value,
                'statuslight4':light4.value,
                'statussocket1':socket1.value,        
                'statussocket2':socket2.value,
                'statussocket3':socket3.value,
                'statussocket4':socket4.value,
                'statuscooler':coolerToFrontend,
                'statusfreeze':freeze.value,
                'statusac':ac.value,
                'statusslider':slider.value

            }) ,  
            success:function(response){
                console.log("success")
            },
            error: function(response){
                console.log("Failed")
            }
        })
    
    })
    $("#freeze").change(function(){
    
        let freezeToFrontend;
        if(freeze.checked){
            freezeToFrontend = 1
        }else{
            freezeToFrontend = 0
        }
        freeze.value=freezeToFrontend
        $.ajax({
            type:'POST',
            url:'applianceStatus/',
            data:({
                'statuslight1':light1.value,
                'statuslight2':light2.value,
                'statuslight3':light3.value,
                'statuslight4':light4.value,
                'statussocket1':socket1.value,        
                'statussocket2':socket2.value,
                'statussocket3':socket3.value,
                'statussocket4':socket4.value,
                'statuscooler':cooler.value,
                'statusfreeze':freezeToFrontend,
                'statusac':ac.value,
                'statusslider':slider.value

            }) ,  
            success:function(response){
                console.log("success")
            },
            error: function(response){
                console.log("Failed")
            }
        })
    
    })
    $("#ac").change(function(){
    
        let acToFrontend;
        if(ac.checked){
            acToFrontend = 1
        }else{
            acToFrontend = 0
        }
        ac.value=acToFrontend
        $.ajax({
            type:'POST',
            url:'applianceStatus/',
            data:({
                'statuslight1':light1.value,
                'statuslight2':light2.value,
                'statuslight3':light3.value,
                'statuslight4':light4.value,
                'statussocket1':socket1.value,        
                'statussocket2':socket2.value,
                'statussocket3':socket3.value,
                'statussocket4':socket4.value,
                'statuscooler':cooler.value,
                'statusfreeze':freeze.value,
                'statusac':acToFrontend,
                'statusslider':slider.value

            }) ,  
            success:function(response){
                console.log("success")
            },
            error: function(response){
                console.log("Failed")
            }
        })
    
    })
    $(".slider1").change(function(){    
        
        $.ajax({
            type:'POST',
            url:'applianceStatus/',
            data:({
                'statuslight1':light1.value,
                'statuslight2':light2.value,
                'statuslight3':light3.value,
                'statuslight4':light4.value,
                'statussocket1':socket1.value,        
                'statussocket2':socket2.value,
                'statussocket3':socket3.value,
                'statussocket4':socket4.value,
                'statuscooler':cooler.value,
                'statusfreeze':freeze.value,
                'statusac':ac.value,
                'statusslider':slider.value

            }) ,  
            success:function(response){
                console.log("success")
            },
            error: function(response){
                console.log("Failed")
            }
        })
    
    })
    $("#moveOut").change(function(){

            moveOut.checked = false
            light1.value = 0
            light2.value = 0
            light3.value = 0
            light4.value = 0
            socket1.value = 0      
            socket2.value = 0
            socket3.value = 0
            socket4.value = 0
            cooler.value = 0
            freeze.value = 0
            ac.value = 0
            slider.value = 0
            $.ajax({
                type:'POST',
                url:'applianceStatus/',
                data:({
                    'statuslight1':'0',
                    'statuslight2':'0',
                    'statuslight3':'0',
                    'statuslight4':'0',
                    'statussocket1':'0',        
                    'statussocket2':'0',
                    'statussocket3':'0',
                    'statussocket4':'0',
                    'statuscooler':'0',
                    'statusfreeze':'0',
                    'statusac':'0',
                    'statusslider':'0'
    
                }) ,  
                success:function(response){
                    console.log("success")
                },
                error: function(response){
                    console.log("Failed")
                }
            })
        
        
    
    })
} 
frontToBack()

    
    







// Backend to Javascript file via html 

function backToFront(){

    console.log("this is ajax")
    $(document).ready(function(){
    
        setInterval(function(){
            $.ajax({
                type:'GET',
                url:'homePage',
                success:function(response){
                    // Bulb1
                    // console.log(response)
                    if(response.bulb1===1){
                        light1.checked=true;
                    }
                    else{
                        light1.checked=false;
                    }
                    // Bulb2
                    if(response.bulb2===1){
                        light2.checked=true;
                    }
                    else{
                        light2.checked=false;
                    }
                    // Bulb3
                    if(response.bulb3===1){
                        light3.checked=true;
                    }
                    else{
                        light3.checked=false;
                    }
                    // Bulb4
                    if(response.bulb4===1){
                        light4.checked=true;
                    }
                    else{
                        light4.checked=false;
                    }
                    // Socket1
                    if(response.socket1===1){
                        socket1.checked=true;
                    }
                    else{
                        socket1.checked=false;
                    }
                    // Socket2
                    if(response.socket2===1){
                        socket2.checked=true;
                    }
                    else{
                        socket2.checked=false;
                    }
                    // Socket3
                    if(response.socket3===1){
                        socket3.checked=true;
                    }
                    else{
                        socket3.checked=false;
                    }
                    // Socket4
                    if(response.socket4===1){
                        socket4.checked=true;
                    }
                    else{
                        socket4.checked=false;
                    }
                    // Cooler
                    if(response.cooler===1){
                        cooler.checked=true;
                    }
                    else{
                        cooler.checked=false;
                    }
                    // Freeze
                    if(response.freeze===1){
                        freeze.checked=true;
                    }
                    else{
                        freeze.checked=false;
                    }
                    // AC
                    if(response.ac===1){
                        ac.checked=true;
                    }
                    else{
                        ac.checked=false;
                    }
                    // // Fan
                    if(0<response.fan && response.fan<=25){
                        progressBar.style.width = 25 + '%';
                        document.getElementById("speed").innerHTML = 25;
                    }else if(25<response.fan && response.fan<=50){
                        progressBar.style.width = 50 + '%';
                        document.getElementById("speed").innerHTML = 50;
                    }else if(50<response.fan && response.fan<=75){
                        progressBar.style.width = 75 + '%';
                        document.getElementById("speed").innerHTML = 75;
                    }else if(75<response.fan && response.fan<=100){
                        progressBar.style.width = 100 + '%';
                        document.getElementById("speed").innerHTML = 100;
                    }else{
                        progressBar.style.width = 0 + '%';
                        document.getElementById("speed").innerHTML = 0;
                    }
                    
                },
                error: function(response){
                    console.log("error found in ajax")
                }
    
            })
        },1000);
    })
}
backToFront();
console.log("Yes")


