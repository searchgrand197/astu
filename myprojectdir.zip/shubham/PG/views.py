from django.contrib.auth.decorators import user_passes_test
import string
from .models import GeneratedCoupon,WithdrawalRequest
import random
from django.contrib import messages
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from .models import AppliancesList,Coupon
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
import boto3

# paste aws here
client = boto3.Session(
    aws_access_key_id = "AKIA3O377A4CJ3FHDB7E",
    aws_secret_access_key = "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",
    region_name = "us-east-1",
)
dynamodb = client.resource('dynamodb')
table = dynamodb.Table('PGDashboard')
def is_superuser(user):
    return user.is_superuser
@user_passes_test(is_superuser)
def create_user(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Create the user
        user = User.objects.create_user(username=username, password=password)
        messages.success(request, f"User '{username}' created successfully!")
        return redirect('create_user')  # Redirect to the same page to clear form

    return render(request, 'PG/create_user.html')
# Index function, Rendering the main page

# Login
def loginPage(request):
    if request.user.is_authenticated:
        return redirect('k')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password =request.POST.get('password')
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('k')
            else:
                messages.info(request, 'Username OR password is incorrect')

    context = {}
    return render(request, 'PG/login.html', context)

# Logout
@login_required(login_url = 'login')
def logoutUser(request):
    logout(request)
    return redirect('login')

# Wallet
@login_required(login_url = 'login')
def index(request):
    walletData = AppliancesList.objects.get(i_name=request.user)
    context={
        "wallet":walletData
    }
    print(context)
    return render(request,'PG/wallet.html',context)
@login_required
def couponlist(request):
    print("here")
    coupons = Coupon.objects.filter(user=request.user, used=True)
    return render(request, 'PG/couponlist.html', {'coupons': coupons})
@login_required
def insert_coupon(request):
    coupon_code=""
    popup_message = ""
    if request.method == 'POST':
        coupon_code = request.POST.get('coupon_code')

        try:
            coupon = GeneratedCoupon.objects.get(code=coupon_code, used=False)
            user_data=Coupon(code=coupon_code, value=coupon.value, user=request.user, used=True)
            walletData = AppliancesList.objects.get(i_name=request.user)
            walletData.total_amount=int(walletData.total_amount) +int(coupon.value)
            coupon.used = True
            coupon.user = request.user
            walletData.save()
            coupon.save()
            user_data.save()
            messages.success(request,"coupons added successfully!")
            popup_message = "coupons added successfully!"
        except GeneratedCoupon.DoesNotExist:  # Use GeneratedCoupon.DoesNotExist here
            print("error")
            messages.error(request, "Invalid coupon code. Please try again.")

    return render(request, 'PG/insert-coupon.html',{'popup_message': popup_message})
@user_passes_test(is_superuser)
def generate_coupon(request):
    if request.method == 'POST':
        min_coupon_value = int(request.POST.get('min_coupon_value'))
        max_coupon_value = int(request.POST.get('max_coupon_value'))
        num_coupons = int(request.POST.get('num_coupons'))

        for _ in range(num_coupons):
            coupon_code = generate_coupon_code()
            coupon_value = random.randint(min_coupon_value, max_coupon_value)

            coupon = GeneratedCoupon(code=coupon_code, value=coupon_value, used=False)
            coupon.save()

        messages.success(request, f"{num_coupons} coupons generated successfully!")

    return render(request, 'PG/generate_coupon.html')
# def generate_coupon(request):
#     if request.method == 'POST':
#         num_coupons = int(request.POST.get('num_coupons'))
#
#         for _ in range(num_coupons):
#             coupon_code = generate_coupon_code()
#             coupon_value = random.randint(4, 10)
#
#             coupon = GeneratedCoupon(code=coupon_code, value=coupon_value, used=False)
#             coupon.save()
#
#         messages.success(request, f"{num_coupons} coupons generated successfully!")
#
#     return render(request, 'PG/generate_coupon.html')

def generate_coupon_code():
    characters = string.digits
    coupon_code = ''.join(random.choice(characters) for _ in range(6))
    return coupon_code
@login_required
def transfer_request(request):
    print("hi")
    user = request.user
    appliances = AppliancesList.objects.filter(i_name=user).first()
    if appliances:
        total_amount = appliances.total_amount
        if total_amount > 0:
            approved_amount = total_amount
            withdrawal_amount = total_amount  # Assuming user wants to withdraw the full amount
            withdrawal_request = WithdrawalRequest(user=user, withdrawal_amount=withdrawal_amount)
            withdrawal_request.save()
            appliances.total_amount = 0
            appliances.save()
            messages.success(request, f"Withdrawal of {approved_amount} ₹ approved and transferred.")
        else:
            messages.error(request, "Insufficient balance for withdrawal.")
    else:
        messages.error(request, "No appliances found for the user.")

    return redirect('k')  # Redirect to the user's profile page

# Assume 'profile' is the URL name for the user's profile page
