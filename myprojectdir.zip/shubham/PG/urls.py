from django.urls import path
from . import views
urlpatterns = [
    path('',views.index,name="k"),
    path('insert-coupon/', views.insert_coupon, name='insert-coupon'),
    path('login/',views.loginPage,name="login"),
    path('logout/', views.logoutUser, name="logout"),
    path('couponlist/', views.couponlist, name='couponlist'),
    path('generate-coupon/', views.generate_coupon, name='generate_coupon'),
    path('transfer-request/', views.transfer_request, name='transfer_request'),
    path('create_user/', views.create_user, name='create_user'),



]
