from django.contrib import admin
from .models import AppliancesList,Coupon,GeneratedCoupon,WithdrawalRequest
# Register your models here.

admin.site.register(AppliancesList)
admin.site.register(Coupon)
admin.site.register(GeneratedCoupon)
admin.site.register(WithdrawalRequest)
