from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.utils.translation import gettext_lazy as _

class CustomUserCreationForm(UserCreationForm):
    password = forms.CharField(
        label=_("Password"),
        strip=False,
        widget=forms.PasswordInput(attrs={'autocomplete': 'new-password'}),
        help_text=_("Enter a 4-digit password."),
    )

    def clean_password(self):
        password = self.cleaned_data.get('password')
        if len(password) != 4 or not password.isdigit():
            raise forms.ValidationError("Password must be a 4-digit number.")
        return password
