from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
# Create your models here.
import random
import string
import uuid
class AppliancesList(models.Model):
    id = models.UUIDField(default=uuid.uuid4,primary_key=True,unique=True,editable=True)
    i_name = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    device_name = models.CharField(max_length=10, null=True)
    total_amount = models.FloatField()
    def __str__(self):
        return f"{self.i_name} - {self.total_amount}"
class Coupon(models.Model):
    code = models.CharField(max_length=20, unique=True)
    value = models.DecimalField(max_digits=10, decimal_places=2)
    user = models.ForeignKey(User, on_delete=models.CASCADE,blank=True)
    used = models.BooleanField(default=False)
    def __str__(self):
        return f"{self.user} - {self.value}"
class GeneratedCoupon(models.Model):
    code = models.CharField(max_length=6, unique=True, default=None)
    value = models.DecimalField(max_digits=10, decimal_places=2)
    used = models.BooleanField(default=False)
    def __str__(self):
        return f"{self.code} - {self.used}"
class WithdrawalRequest(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('transferred', 'Transferred'),
    )

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    withdrawal_amount = models.FloatField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    def __str__(self):
        return f"{self.user} - {self.status}"